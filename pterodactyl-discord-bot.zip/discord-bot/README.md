# 🤖 Pterodactyl Discord Bot

A Discord bot to manage Pterodactyl game servers via MongoDB.

---

## 📁 File Structure

```
discord-bot/
├── index.js                  # Bot entry point
├── package.json
├── .env.example              # Copy to .env and fill in
├── commands/
│   └── help.js               # n!help @user command
├── handlers/
│   └── serverHandler.js      # Button click → start → diagnose → fix → ticket
├── models/
│   └── User.js               # MongoDB user schema
└── utils/
    └── pterodactyl.js        # Pterodactyl API calls
```

---

## ⚙️ Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
```

Fill in `.env`:

| Variable              | Description                                      |
|-----------------------|--------------------------------------------------|
| `DISCORD_TOKEN`       | Your bot token from Discord Developer Portal     |
| `PREFIX`              | Command prefix (default: `n!`)                   |
| `MONGO_URI`           | Your MongoDB connection string                   |
| `PTERODACTYL_URL`     | Your panel URL, e.g. `https://panel.example.com` |
| `PTERODACTYL_API_KEY` | Admin API key from the panel                     |
| `ADMIN_ROLE_ID`       | Discord role ID that can use this bot            |
| `TICKET_CHANNEL_ID`   | Channel ID where error reports are sent          |

### 3. Run the bot
```bash
npm start
# or for development with auto-reload:
npm run dev
```

---

## 🗄️ MongoDB Schema

Your `users` collection must look like this:

```json
{
  "discordId": "123456789012345678",
  "username": "PlayerName",
  "pterodactylUserId": 42,
  "servers": [
    {
      "serverId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
      "serverName": "My Minecraft Server",
      "identifier": "abc1def2"
    }
  ]
}
```

- `serverId` → full UUID from Pterodactyl panel
- `identifier` → short ID (first 8 chars, shown in panel URL)

---

## 🚀 Usage

```
n!help @username
```

1. Bot checks the mentioned user's Discord ID in MongoDB
2. If they have servers → shows an embed with buttons (one per server)
3. **Only admins** (set via `ADMIN_ROLE_ID`) can click buttons
4. On click → bot starts the server via Pterodactyl API
5. After 6 seconds → checks server state:
   - ✅ Running → success message
   - ❌ Error → auto-diagnosis runs:
     - Missing npm module → triggers reinstall
     - Port conflict → kill + restart
     - Out of memory → restart + manual warning
     - Unknown error → sends raw error to ticket channel

---

## 🔧 Adding More Auto-Fix Patterns

In `handlers/serverHandler.js`, add entries to the `KNOWN_ERRORS` array:

```js
{
  pattern: /your regex here/i,
  label: 'Short description',
  fix: async (match, identifier) => ({
    action: 'What fix was applied',
    detail: 'Longer explanation',
    autoFixed: true,      // true = bot attempted a fix
    requiresReinstall: false,
  }),
},
```

---

## 📋 Required Discord Bot Permissions

- Read Messages / View Channels
- Send Messages
- Embed Links
- Read Message History
- Use External Emojis
- Add Reactions
- Manage Messages (optional, for cleanup)

Enable **Message Content Intent** in the Discord Developer Portal under your bot settings.
