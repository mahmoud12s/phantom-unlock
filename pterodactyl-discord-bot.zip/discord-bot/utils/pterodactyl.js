const fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args));

const BASE_URL = process.env.PTERODACTYL_URL;
const API_KEY  = process.env.PTERODACTYL_API_KEY;

const headers = {
  'Authorization': `Bearer ${API_KEY}`,
  'Accept': 'application/json',
  'Content-Type': 'application/json',
};

/**
 * Send a power signal to a server.
 * @param {string} serverId - Pterodactyl server UUID
 * @param {string} signal   - 'start' | 'stop' | 'restart' | 'kill'
 */
async function sendPowerSignal(serverId, signal = 'start') {
  const res = await fetch(`${BASE_URL}/api/application/servers/${serverId}/power`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ signal }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(`Power signal failed: ${res.status} - ${JSON.stringify(err)}`);
  }
  return true;
}

/**
 * Get server details from Pterodactyl.
 * @param {string} serverId - Pterodactyl server UUID
 */
async function getServerDetails(serverId) {
  const res = await fetch(`${BASE_URL}/api/application/servers/${serverId}`, { headers });
  if (!res.ok) throw new Error(`Failed to fetch server: ${res.status}`);
  return res.json();
}

/**
 * Get server resource usage / status.
 * @param {string} identifier - Short identifier (from client API)
 */
async function getServerStatus(identifier) {
  const res = await fetch(`${BASE_URL}/api/client/servers/${identifier}/resources`, {
    headers: {
      'Authorization': `Bearer ${API_KEY}`,
      'Accept': 'application/json',
    },
  });
  if (!res.ok) throw new Error(`Failed to fetch status: ${res.status}`);
  return res.json();
}

/**
 * Get recent server logs.
 * @param {string} identifier - Short identifier
 */
async function getServerLogs(identifier) {
  // Pterodactyl doesn't expose logs via REST directly — we retrieve startup logs
  // via websocket. For simplicity we return the startup command and status.
  const details = await getServerStatus(identifier);
  return details;
}

/**
 * Reinstall a server (can fix some package / dependency issues).
 * @param {string} serverId - UUID
 */
async function reinstallServer(serverId) {
  const res = await fetch(`${BASE_URL}/api/application/servers/${serverId}/reinstall`, {
    method: 'POST',
    headers,
  });
  if (!res.ok) throw new Error(`Reinstall failed: ${res.status}`);
  return true;
}

module.exports = {
  sendPowerSignal,
  getServerDetails,
  getServerStatus,
  getServerLogs,
  reinstallServer,
};
