const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  discordId: { type: String, required: true, unique: true },
  username: { type: String },
  pterodactylUserId: { type: Number },
  servers: [
    {
      serverId: { type: String },      // Pterodactyl server UUID
      serverName: { type: String },
      identifier: { type: String },    // Short ID
    }
  ],
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('User', userSchema);
