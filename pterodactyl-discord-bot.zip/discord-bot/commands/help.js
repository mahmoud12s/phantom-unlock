const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const User = require('../models/User');

module.exports = {
  name: 'help',

  async execute(message, args, client) {
    // ── 1. Permission check ──────────────────────────────────────────────────
    const adminRoleId = process.env.ADMIN_ROLE_ID;
    if (!message.member.roles.cache.has(adminRoleId)) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xe74c3c)
            .setTitle('🚫 Access Denied')
            .setDescription('Only **Admins** can use this command.')
            .setTimestamp(),
        ],
      });
    }

    // ── 2. Validate mention ──────────────────────────────────────────────────
    const mentioned = message.mentions.users.first();
    if (!mentioned) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xe67e22)
            .setTitle('⚠️ Usage')
            .setDescription('`n!help @user`\nMention a user to check their servers.')
            .setTimestamp(),
        ],
      });
    }

    // ── 3. Fetch user from MongoDB ───────────────────────────────────────────
    const userData = await User.findOne({ discordId: mentioned.id });

    if (!userData || !userData.servers || userData.servers.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x95a5a6)
            .setTitle('📭 No Servers Found')
            .setDescription(`**${mentioned.username}** has no servers linked in the database.`)
            .setThumbnail(mentioned.displayAvatarURL())
            .setTimestamp(),
        ],
      });
    }

    // ── 4. Build buttons (one per server, max 25 per Discord limit) ──────────
    const servers = userData.servers.slice(0, 25);
    const rows = [];

    // Discord allows max 5 buttons per row, max 5 rows
    for (let i = 0; i < servers.length; i += 5) {
      const row = new ActionRowBuilder();
      const chunk = servers.slice(i, i + 5);

      chunk.forEach((srv) => {
        row.addComponents(
          new ButtonBuilder()
            .setCustomId(`start_server_${srv.serverId}__${mentioned.id}`)
            .setLabel(`🚀 ${srv.serverName}`)
            .setStyle(ButtonStyle.Primary)
        );
      });

      rows.push(row);
    }

    // ── 5. Build main embed ──────────────────────────────────────────────────
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`🖥️ Servers — ${mentioned.username}`)
      .setThumbnail(mentioned.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `Found **${servers.length}** server(s) linked to <@${mentioned.id}>.\n` +
        `Click a button below to **start** that server and run diagnostics.`
      )
      .addFields(
        servers.map((srv, i) => ({
          name: `${i + 1}. ${srv.serverName}`,
          value: `\`ID: ${srv.serverId}\``,
          inline: true,
        }))
      )
      .setFooter({ text: '⚠️ Only Admins can interact with these buttons.' })
      .setTimestamp();

    await message.reply({ embeds: [embed], components: rows });
  },
};
