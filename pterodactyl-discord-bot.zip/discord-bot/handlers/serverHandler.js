const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const pterodactyl = require('../utils/pterodactyl');

// ─── Known auto-fixable error patterns ────────────────────────────────────────
const KNOWN_ERRORS = [
  {
    pattern: /cannot find module '(.+?)'/i,
    label: 'Missing Node module',
    fix: async (match, identifier) => {
      const pkg = match[1];
      return {
        action: `Install missing package: \`${pkg}\``,
        detail: `The server startup failed because \`${pkg}\` is not installed. ` +
                `A reinstall has been triggered to restore dependencies.`,
        autoFixed: true,
        requiresReinstall: true,
      };
    },
  },
  {
    pattern: /error: could not find '(.+?)'/i,
    label: 'Missing binary / package',
    fix: async (match) => ({
      action: `Missing binary: \`${match[1]}\``,
      detail: `A required executable was not found. Reinstalling the server to restore it.`,
      autoFixed: true,
      requiresReinstall: true,
    }),
  },
  {
    pattern: /eaddrinuse|address already in use/i,
    label: 'Port already in use',
    fix: async () => ({
      action: 'Port conflict detected',
      detail: 'The port is already occupied. A restart signal has been sent to clear the process.',
      autoFixed: true,
      requiresReinstall: false,
    }),
  },
  {
    pattern: /out of memory|javascript heap out of memory/i,
    label: 'Out of memory',
    fix: async () => ({
      action: 'Memory limit reached',
      detail: 'The server ran out of memory. A restart has been triggered. ' +
              'Consider upgrading the memory allocation in the panel.',
      autoFixed: false,
      requiresReinstall: false,
    }),
  },
];

// ─── Diagnose error string against known patterns ──────────────────────────────
function diagnose(errorText) {
  for (const entry of KNOWN_ERRORS) {
    const match = errorText.match(entry.pattern);
    if (match) return { entry, match };
  }
  return null;
}

// ─── Send a report to the ticket channel ──────────────────────────────────────
async function sendTicketReport(client, { serverName, serverId, errorText, fixResult, adminTag }) {
  const ticketChannelId = process.env.TICKET_CHANNEL_ID;
  if (!ticketChannelId) return;

  const channel = await client.channels.fetch(ticketChannelId).catch(() => null);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(fixResult?.autoFixed ? 0xf39c12 : 0xe74c3c)
    .setTitle(`🎫 Server Diagnostic Report`)
    .addFields(
      { name: '🖥️ Server', value: `\`${serverName}\``, inline: true },
      { name: '🆔 UUID', value: `\`${serverId}\``, inline: true },
      { name: '👤 Triggered by', value: adminTag, inline: true },
    )
    .setTimestamp();

  if (fixResult) {
    embed
      .addFields(
        { name: '🔍 Detected Issue', value: fixResult.action },
        { name: '📋 Details', value: fixResult.detail },
        {
          name: fixResult.autoFixed ? '✅ Auto-Fix Applied' : '❌ Manual Fix Required',
          value: fixResult.autoFixed
            ? 'The bot attempted an automatic fix. Please verify the server status.'
            : 'This issue could **not** be fixed automatically. Manual intervention is needed.',
        },
      )
      .setColor(fixResult.autoFixed ? 0xf39c12 : 0xe74c3c);
  } else {
    embed.addFields(
      { name: '❓ Unknown Error', value: 'No matching auto-fix pattern was found.' },
      { name: '📄 Raw Error (truncated)', value: `\`\`\`\n${errorText.slice(0, 800)}\n\`\`\`` },
    );
  }

  await channel.send({ embeds: [embed] });
}

// ─── Main handler ──────────────────────────────────────────────────────────────
async function handleStartServer(interaction, client) {
  // ── Admin role check ──
  const adminRoleId = process.env.ADMIN_ROLE_ID;
  if (!interaction.member.roles.cache.has(adminRoleId)) {
    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('🚫 Access Denied')
          .setDescription('Only **Admins** can use these buttons.'),
      ],
      ephemeral: true,
    });
  }

  // ── Parse customId: "start_server_{uuid}__{discordId}" ──
  const raw = interaction.customId.replace('start_server_', '');
  const splitIndex = raw.lastIndexOf('__');
  const serverId  = raw.slice(0, splitIndex);
  // const ownerId = raw.slice(splitIndex + 2); // available if needed

  await interaction.deferReply({ ephemeral: false });

  // ── Step 1: Fetch server details ──
  let serverDetails;
  try {
    serverDetails = await pterodactyl.getServerDetails(serverId);
  } catch (err) {
    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xe74c3c)
          .setTitle('❌ Could not fetch server')
          .setDescription(`\`\`\`${err.message}\`\`\``)
          .setTimestamp(),
      ],
    });
  }

  const serverName = serverDetails?.attributes?.name || serverId;
  const identifier = serverDetails?.attributes?.identifier || serverId;

  // ── Step 2: Send start signal ──
  const startEmbed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`⚡ Starting Server — ${serverName}`)
    .setDescription('Sending start signal to Pterodactyl...')
    .setTimestamp();

  await interaction.editReply({ embeds: [startEmbed] });

  let startError = null;
  try {
    await pterodactyl.sendPowerSignal(serverId, 'start');
  } catch (err) {
    startError = err.message;
  }

  // ── Step 3: Wait a few seconds then check status ──
  await new Promise(r => setTimeout(r, 6000));

  let status;
  let statusError = null;
  try {
    status = await pterodactyl.getServerStatus(identifier);
  } catch (err) {
    statusError = err.message;
  }

  const serverState = status?.attributes?.current_state || 'unknown';
  const isRunning   = serverState === 'running';

  if (isRunning) {
    // ✅ Server started fine
    return interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x2ecc71)
          .setTitle(`✅ Server Started — ${serverName}`)
          .addFields(
            { name: '📊 Status', value: `\`${serverState}\``, inline: true },
            { name: '🆔 Identifier', value: `\`${identifier}\``, inline: true },
          )
          .setDescription('The server is now **online** and running normally.')
          .setTimestamp(),
      ],
    });
  }

  // ── Step 4: Server not running — diagnose ──
  const rawError = startError || statusError || `Server state: ${serverState}`;
  const diagnosis = diagnose(rawError);

  let fixResult = null;

  if (diagnosis) {
    fixResult = await diagnosis.entry.fix(diagnosis.match, identifier);

    // Attempt auto-fix
    if (fixResult.requiresReinstall) {
      try {
        await pterodactyl.reinstallServer(serverId);
        await new Promise(r => setTimeout(r, 4000));
        await pterodactyl.sendPowerSignal(serverId, 'start');
      } catch (e) {
        fixResult.autoFixed = false;
        fixResult.detail += `\n\n⚠️ Auto-fix attempt failed: ${e.message}`;
      }
    } else {
      // For non-reinstall fixes (e.g. port conflict) — just restart
      try {
        await pterodactyl.sendPowerSignal(serverId, 'kill');
        await new Promise(r => setTimeout(r, 2000));
        await pterodactyl.sendPowerSignal(serverId, 'start');
      } catch (e) {
        fixResult.autoFixed = false;
      }
    }
  }

  // ── Step 5: Send ticket report ──
  await sendTicketReport(client, {
    serverName,
    serverId,
    errorText: rawError,
    fixResult,
    adminTag: `${interaction.user.tag} (<@${interaction.user.id}>)`,
  });

  // ── Step 6: Edit reply with diagnostic result ──
  const resultEmbed = new EmbedBuilder()
    .setTimestamp()
    .setTitle(`🔧 Diagnostic — ${serverName}`);

  if (fixResult) {
    resultEmbed
      .setColor(fixResult.autoFixed ? 0xf39c12 : 0xe74c3c)
      .setDescription(
        fixResult.autoFixed
          ? `✅ **Auto-fix applied.** A report was sent to <#${process.env.TICKET_CHANNEL_ID}>.`
          : `❌ **Could not auto-fix.** A report was sent to <#${process.env.TICKET_CHANNEL_ID}>.`
      )
      .addFields(
        { name: '🔍 Issue', value: fixResult.action },
        { name: '📋 Detail', value: fixResult.detail },
      );
  } else {
    resultEmbed
      .setColor(0xe74c3c)
      .setDescription(`❓ Unknown error — a report was sent to <#${process.env.TICKET_CHANNEL_ID}>.`)
      .addFields({ name: '📄 Raw Error', value: `\`\`\`\n${rawError.slice(0, 500)}\n\`\`\`` });
  }

  return interaction.editReply({ embeds: [resultEmbed] });
}

module.exports = { handleStartServer };
